# README

9/15/16 Emily Davenport

This directory contains information from the **altmetrics** study, _including_:  

* data files  
* scripts  
* results 

To view this README, type `cat README.md`. 

To ensure the rmarkdown package is installed, in R type the following:

```
install.packages("rmarkdown")
```

The data for this project originally came from [Priem et al. 2012](http://arxiv.org/abs/1203.4745)

The processed data files were downloaded 9/15/2016, including both the [raw count data][link1] and the [normalized data][link2].

[link1]: https://raw.githubusercontent.com/jdblischak/r-intermediate-altmetrics/gh-pages/data/counts-raw.txt.gz
[link2]: https://raw.githubusercontent.com/jdblischak/r-intermediate-altmetrics/gh-pages/data/counts-form.txt.gz