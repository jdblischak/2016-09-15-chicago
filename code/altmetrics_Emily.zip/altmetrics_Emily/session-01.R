# Read data into R
counts_raw <- read.delim("data/counts-raw.txt.gz")

dim(counts_raw)

head(counts_raw, 1)

counts_raw[1,2]
1:5
counts_raw[1:5, 1:5]

counts_raw[1:5, ]

counts_raw[1:5, "pmid"]

class(counts_raw)
str(counts_raw$daysSincePublished)

str(counts_raw$daysSincePublished / 7)

is.numeric(counts_raw$daysSincePublished)

is.numeric("cow")

str(counts_raw$journal)

levels(counts_raw$journal)

head(counts_raw$journal)

counts_raw$authorsCount[1:10]

is.na(counts_raw$authorsCount[1:10])

anyNA(counts_raw$authorsCount[1:10])

summary(counts_raw$wosCountThru2011)

summary(counts_raw$wosCountThru2011)["Mean"]

mean(counts_raw$wosCountThru2011)

sd(counts_raw$wosCountThru2011)

mymedian <- median(counts_raw$wosCountThru2011)

hist(counts_raw$wosCountThru2011)
?hist

plot(counts_raw$daysSincePublished, counts_raw$wosCountThru2011)

hist(log(counts_raw$wosCountThru2011 + 1))

plot(counts_raw$daysSincePublished / 7, log(counts_raw$wosCountThru2011 + 1))
